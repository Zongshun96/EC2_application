# coding: utf-8
"""NDArray namespace used to register contrib functions"""
